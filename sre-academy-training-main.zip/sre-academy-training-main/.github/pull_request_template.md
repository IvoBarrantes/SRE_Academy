---
name: Pull request
about: Describe the changes you’re proposing
title: ''
labels: ''
assignees: ''
---

## Description

Please include a summary of the change and which issue is fixed.  
Also include motivation and context.

Fixes # (issue)

## Related Issues

- Closes #<issue-number>  
- Depends on #<issue-number> (if applicable)  

## How Has This Been Tested?

Describe the tests you ran to verify your changes, and any special setup.

1.  
2.  
3.  

## Checklist

- [ ] My code follows the style guidelines of this project  
- [ ] I have performed a self-review of my code  
- [ ] I have added or updated tests where applicable  
- [ ] New and existing unit tests pass locally  
